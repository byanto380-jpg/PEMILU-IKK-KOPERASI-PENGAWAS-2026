# E-Voting Koperasi — React + Tailwind + Node/Express + MySQL

Full-stack starter untuk RAT/e-voting koperasi.

## Fitur
- Database anggota, kandidat, admin, periode pemilihan, token voting, dan suara.
- Login pemilih dengan nomor anggota + token sekali pakai.
- Token voting di-hash di database dan ditandai terpakai setelah suara tersimpan.
- Admin CRUD anggota/kandidat/periode.
- Aktivasi/nonaktif periode dan pengaturan waktu mulai/selesai.
- Hasil voting real-time via Socket.IO.
- Export hasil ke Excel (.xlsx) dan PDF.
- Audit log dasar untuk login, penerbitan token, voting, dan perubahan admin.
- Transaksi database untuk mencegah double vote.

## Menjalankan
### 1. Database
Buat database MySQL lalu jalankan `backend/sql/schema.sql`.

Salin `.env.example` menjadi `.env` di folder backend.

### 2. Backend
```bash
cd backend
npm install
npm run dev
```

### 3. Frontend
```bash
cd frontend
npm install
npm run dev
```

Default frontend: http://localhost:5173
Default API: http://localhost:4000

## Akun demo
Setelah menjalankan seed:
- Admin: `admin` / `admin123`
- Anggota: `KOP-2026-001`
- Token demo: dicetak oleh endpoint admin `/api/admin/tokens` atau gunakan seed token yang ditampilkan saat `npm run seed`.

> Untuk produksi, ganti kredensial demo, gunakan HTTPS, secret yang kuat, backup database, dan lakukan audit keamanan sebelum pemilu nyata.
