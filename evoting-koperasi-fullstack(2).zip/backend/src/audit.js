import {pool} from './db.js';
export async function audit(actorType, actorId, action, details={}) { await pool.query('INSERT INTO audit_logs(actor_type,actor_id,action,details) VALUES (?,?,?,?)',[actorType,actorId,action,JSON.stringify(details)]); }
