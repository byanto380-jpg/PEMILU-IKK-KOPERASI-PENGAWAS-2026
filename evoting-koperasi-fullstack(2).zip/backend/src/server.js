import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import {createServer} from 'http';
import {Server} from 'socket.io';
import {pool} from './db.js';
import {sign,verify,role,hashToken,randomToken} from './auth.js';
import {audit} from './audit.js';
import XLSX from 'xlsx';
import PDFDocument from 'pdfkit';

dotenv.config();
const app=express(); const http=createServer(app); const io=new Server(http,{cors:{origin:process.env.CLIENT_URL||'http://localhost:5173'}});
app.use(cors({origin:process.env.CLIENT_URL||'http://localhost:5173'})); app.use(express.json());
const q=async(sql,p=[])=>{const [r]=await pool.query(sql,p);return r;};

app.get('/api/health',(req,res)=>res.json({ok:true}));
app.post('/api/auth/member-login',async(req,res)=>{const {memberNo,token}=req.body; if(!memberNo||!token)return res.status(400).json({message:'Nomor anggota dan token wajib diisi'});
 const m=(await q('SELECT * FROM members WHERE member_no=? AND status="ACTIVE"',[memberNo]))[0]; if(!m)return res.status(401).json({message:'Anggota tidak ditemukan/aktif'});
 const e=(await q('SELECT * FROM elections WHERE status="ACTIVE" AND NOW() BETWEEN start_at AND end_at ORDER BY id DESC LIMIT 1'))[0]; if(!e)return res.status(400).json({message:'Belum ada periode voting aktif'});
 const t=(await q('SELECT * FROM voting_tokens WHERE election_id=? AND member_id=? AND token_hash=? AND used_at IS NULL AND expires_at>=NOW()',[e.id,m.id,hashToken(token)]))[0]; if(!t)return res.status(401).json({message:'Token salah, sudah digunakan, atau kedaluwarsa'});
 const voted=(await q('SELECT id FROM votes WHERE election_id=? AND member_id=?',[e.id,m.id]))[0]; await audit('MEMBER',m.id,'MEMBER_LOGIN',{electionId:e.id});
 res.json({token:sign({role:'member',memberId:m.id,electionId:e.id}),member:{id:m.id,memberNo:m.member_no,name:m.name},election:e,voted:!!voted});
});

app.post('/api/auth/admin-login',async(req,res)=>{const {username,password}=req.body;const a=(await q('SELECT * FROM admins WHERE username=?',[username]))[0];if(!a||!(await bcrypt.compare(password,a.password_hash)))return res.status(401).json({message:'Username/password salah'});await audit('ADMIN',a.id,'ADMIN_LOGIN');res.json({token:sign({role:'admin',adminId:a.id}),admin:{id:a.id,name:a.name,username:a.username}});});

app.get('/api/member/candidates',verify,role('member'),async(req,res)=>{const rows=await q('SELECT id,number,name,photo_url,vision,mission FROM candidates WHERE status="ACTIVE" ORDER BY number');res.json(rows.map(x=>({...x,mission:JSON.parse(x.mission)})));});
app.post('/api/member/vote',verify,role('member'),async(req,res)=>{const {candidateId}=req.body; const conn=await pool.getConnection(); try{await conn.beginTransaction(); const [eRows]=await conn.query('SELECT * FROM elections WHERE id=? AND status="ACTIVE" AND NOW() BETWEEN start_at AND end_at FOR UPDATE',[req.user.electionId]);if(!eRows[0])throw new Error('Periode voting tidak aktif');const [cRows]=await conn.query('SELECT id FROM candidates WHERE id=? AND status="ACTIVE"',[candidateId]);if(!cRows[0])throw new Error('Kandidat tidak valid');const [vRows]=await conn.query('SELECT id FROM votes WHERE election_id=? AND member_id=? FOR UPDATE',[req.user.electionId,req.user.memberId]);if(vRows[0])throw new Error('Anda sudah memilih');await conn.query('INSERT INTO votes(election_id,member_id,candidate_id) VALUES (?,?,?)',[req.user.electionId,req.user.memberId,candidateId]);await conn.query('UPDATE voting_tokens SET used_at=NOW() WHERE election_id=? AND member_id=? AND used_at IS NULL',[req.user.electionId,req.user.memberId]);await conn.commit();await audit('MEMBER',req.user.memberId,'CAST_VOTE',{electionId:req.user.electionId,candidateId});const results=await getResults(req.user.electionId);io.emit('results:update',results);res.json({message:'Suara berhasil disimpan'});}catch(err){await conn.rollback();res.status(400).json({message:err.message});}finally{conn.release();}});

async function getResults(electionId){return await q(`SELECT c.id,c.number,c.name,COUNT(v.id) votes,ROUND(COUNT(v.id)*100/GREATEST((SELECT COUNT(*) FROM votes WHERE election_id=?),1),2) percentage FROM candidates c LEFT JOIN votes v ON v.candidate_id=c.id AND v.election_id=? GROUP BY c.id ORDER BY c.number`,[electionId,electionId]);}
app.get('/api/results/:electionId',verify,async(req,res)=>{res.json(await getResults(req.params.electionId));});

app.use('/api/admin',verify,role('admin'));
app.get('/api/admin/members',async(req,res)=>res.json(await q('SELECT * FROM members ORDER BY id DESC')));
app.post('/api/admin/members',async(req,res)=>{const {memberNo,name,email,phone,status='ACTIVE'}=req.body;const r=await q('INSERT INTO members(member_no,name,email,phone,status) VALUES (?,?,?,?,?)',[memberNo,name,email||null,phone||null,status]);await audit('ADMIN',req.user.adminId,'CREATE_MEMBER',{id:r.insertId});res.status(201).json({id:r.insertId});});
app.put('/api/admin/members/:id',async(req,res)=>{const {memberNo,name,email,phone,status}=req.body;await q('UPDATE members SET member_no=?,name=?,email=?,phone=?,status=? WHERE id=?',[memberNo,name,email||null,phone||null,status,req.params.id]);await audit('ADMIN',req.user.adminId,'UPDATE_MEMBER',{id:req.params.id});res.json({ok:true});});
app.delete('/api/admin/members/:id',async(req,res)=>{await q('DELETE FROM members WHERE id=?',[req.params.id]);await audit('ADMIN',req.user.adminId,'DELETE_MEMBER',{id:req.params.id});res.status(204).end();});

app.get('/api/admin/candidates',async(req,res)=>res.json(await q('SELECT id,number,name,photo_url,vision,mission,status FROM candidates ORDER BY number')));
app.post('/api/admin/candidates',async(req,res)=>{const {number,name,photoUrl,vision,mission,status='ACTIVE'}=req.body;const r=await q('INSERT INTO candidates(number,name,photo_url,vision,mission,status) VALUES (?,?,?,?,?,?)',[number,name,photoUrl||null,vision,JSON.stringify(mission||[]),status]);await audit('ADMIN',req.user.adminId,'CREATE_CANDIDATE',{id:r.insertId});res.status(201).json({id:r.insertId});});
app.put('/api/admin/candidates/:id',async(req,res)=>{const {number,name,photoUrl,vision,mission,status}=req.body;await q('UPDATE candidates SET number=?,name=?,photo_url=?,vision=?,mission=?,status=? WHERE id=?',[number,name,photoUrl||null,vision,JSON.stringify(mission||[]),status,req.params.id]);res.json({ok:true});});
app.delete('/api/admin/candidates/:id',async(req,res)=>{await q('DELETE FROM candidates WHERE id=?',[req.params.id]);res.status(204).end();});

app.get('/api/admin/elections',async(req,res)=>res.json(await q('SELECT * FROM elections ORDER BY id DESC')));
app.post('/api/admin/elections',async(req,res)=>{const {name,startAt,endAt}=req.body;const r=await q('INSERT INTO elections(name,start_at,end_at,status) VALUES (?,?,?,"DRAFT")',[name,startAt,endAt]);res.status(201).json({id:r.insertId});});
app.put('/api/admin/elections/:id',async(req,res)=>{const {name,startAt,endAt,status}=req.body;await q('UPDATE elections SET name=?,start_at=?,end_at=?,status=? WHERE id=?',[name,startAt,endAt,status,req.params.id]);res.json({ok:true});});
app.post('/api/admin/elections/:id/activate',async(req,res)=>{await q('UPDATE elections SET status="CLOSED" WHERE status="ACTIVE"');await q('UPDATE elections SET status="ACTIVE" WHERE id=?',[req.params.id]);res.json({ok:true});});
app.post('/api/admin/elections/:id/close',async(req,res)=>{await q('UPDATE elections SET status="CLOSED" WHERE id=?',[req.params.id]);res.json({ok:true});});

app.post('/api/admin/tokens/generate',async(req,res)=>{const {electionId,memberIds}=req.body;const e=(await q('SELECT * FROM elections WHERE id=?',[electionId]))[0];if(!e)return res.status(404).json({message:'Periode tidak ditemukan'});const ids=memberIds?.length?memberIds:(await q('SELECT id FROM members WHERE status="ACTIVE"')).map(x=>x.id);const out=[];
 // Generate raw tokens only in this response; only SHA-256 hashes are stored.
 for(const memberId of ids){const raw=randomToken();const h=hashToken(raw);await q('INSERT INTO voting_tokens(election_id,member_id,token_hash,expires_at) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE token_hash=VALUES(token_hash),used_at=NULL,expires_at=VALUES(expires_at)',[electionId,memberId,h,e.end_at]);out.push({memberId,token:raw});}
 await audit('ADMIN',req.user.adminId,'GENERATE_TOKENS',{electionId,count:out.length});res.json(out);});

app.get('/api/admin/summary/:electionId',async(req,res)=>{const e=req.params.electionId;const total=(await q('SELECT COUNT(*) n FROM members WHERE status="ACTIVE"'))[0].n;const voted=(await q('SELECT COUNT(*) n FROM votes WHERE election_id=?',[e]))[0].n;res.json({totalMembers:total,voted,notVoted:Math.max(total-voted,0),participation:total?Number((voted*100/total).toFixed(2)):0,results:await getResults(e)});});

app.get('/api/admin/export/:electionId/excel',async(req,res)=>{const rows=await getResults(req.params.electionId);const wb=XLSX.utils.book_new();const ws=XLSX.utils.json_to_sheet(rows);XLSX.utils.book_append_sheet(wb,ws,'Hasil Voting');const buf=XLSX.write(wb,{type:'buffer',bookType:'xlsx'});res.setHeader('Content-Disposition','attachment; filename="hasil-voting.xlsx"');res.type('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet').send(buf);});
app.get('/api/admin/export/:electionId/pdf',async(req,res)=>{const rows=await getResults(req.params.electionId);res.setHeader('Content-Disposition','attachment; filename="hasil-voting.pdf"');res.type('application/pdf');const doc=new PDFDocument({margin:50});doc.pipe(res);doc.fontSize(20).text('Laporan Hasil E-Voting Koperasi');doc.moveDown();doc.fontSize(11).text(`Periode ID: ${req.params.electionId}`);doc.moveDown();rows.forEach((r,i)=>doc.text(`${r.number}. ${r.name} — ${r.votes} suara (${r.percentage}%)`));doc.end();});

const PORT=Number(process.env.PORT||4000);http.listen(PORT,()=>console.log(`API running on http://localhost:${PORT}`));
