import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import dotenv from 'dotenv';
dotenv.config();
export const sign = (payload) => jwt.sign(payload, process.env.JWT_SECRET, {expiresIn:'8h'});
export const verify = (req,res,next) => {
  try { const h=req.headers.authorization||''; const token=h.startsWith('Bearer ')?h.slice(7):null; if(!token) return res.status(401).json({message:'Unauthorized'}); req.user=jwt.verify(token,process.env.JWT_SECRET); next(); }
  catch { res.status(401).json({message:'Token tidak valid'}); }
};
export const role = (r) => (req,res,next) => req.user?.role===r ? next() : res.status(403).json({message:'Forbidden'});
export const hashToken = (t)=>crypto.createHash('sha256').update(t).digest('hex');
export const randomToken = ()=>crypto.randomBytes(18).toString('base64url').toUpperCase();
